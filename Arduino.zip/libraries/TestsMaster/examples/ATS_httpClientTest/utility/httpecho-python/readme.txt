Instructions to run the python echo server
