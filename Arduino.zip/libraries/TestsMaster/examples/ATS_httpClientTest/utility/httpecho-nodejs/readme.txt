Instructions to run the node echo
