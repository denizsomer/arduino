The coded for the echo servers used in testing are:
httpecho-nodejs
httpecho-python

Either sever should work to echo the request back.

